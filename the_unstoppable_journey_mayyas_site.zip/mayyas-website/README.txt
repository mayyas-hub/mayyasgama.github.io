THE UNSTOPPABLE JOURNEY — MAYYAS
=================================
Files: index.html (website), style.css (responsive styling), script.js (navigation).
Open index.html in a browser to preview.

PUBLISH WITH GITHUB PAGES
1. Upload index.html, style.css and script.js to the ROOT of your repository.
2. In repository Settings > Pages, choose Deploy from a branch.
3. Select branch main and folder /(root), then Save.
4. Wait for GitHub Pages to publish. Your expected address is https://mayyasgama.github.io/

PUBLICATION CHECK
Review every personal detail before publishing. This draft does not include contact details,
exact residence, or family members' identities. The SwaPay section describes a project vision,
not a launched or available payment service.

The football background image is externally hosted and linked from Europlan. Check its reuse
terms/permission before public or commercial use. External image availability may change.
